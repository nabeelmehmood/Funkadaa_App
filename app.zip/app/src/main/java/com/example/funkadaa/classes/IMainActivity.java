package com.example.funkadaa.classes;

public interface IMainActivity {

        void setimage(String uri);


    }

