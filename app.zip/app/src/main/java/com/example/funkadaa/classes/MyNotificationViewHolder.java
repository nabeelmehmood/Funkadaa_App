package com.example.funkadaa.classes;

import android.app.Notification;
import android.content.Context;
import android.support.v7.widget.RecyclerView;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;

import org.w3c.dom.Text;

/**
 * Created by nabee on 4/19/2018.
 */

public class MyNotificationViewHolder extends RecyclerView.ViewHolder {
    ImageView image;
    TextView notif;
    TextView date;

    public MyNotificationViewHolder(View itemView)
    {
        super(itemView);

    }



}
